
Title: 00README

This is the begining of a linux kernel model duma.  Same idea as 
user space duma, replace kmalloc and friends instead.

This effort is being drivin by:

 * Eric Rachner <eric@rachner.us>
 * Michael Eddington <meddington@phed.org>

