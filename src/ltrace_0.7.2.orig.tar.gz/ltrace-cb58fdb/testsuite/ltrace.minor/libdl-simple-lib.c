int test_libdl(int x)
{
	return x * 1337;
}
